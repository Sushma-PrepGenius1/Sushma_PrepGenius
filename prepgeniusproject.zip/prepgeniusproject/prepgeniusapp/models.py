from django.db import models
from django.contrib.auth.models import User

class FavCategory(models.Model):
    user = models.ForeignKey(User, on_delete=models.CASCADE)
    category_name = models.CharField(max_length=100)

    def __str__(self):
        return f"{self.user.username} - {self.category_name}"

class ResumeDetails(models.Model):
    user = models.ForeignKey(User, on_delete=models.CASCADE)
    resume_path = models.TextField()
    job_description_path = models.TextField()
    job_role = models.CharField(max_length=255, blank=True)
    ats_score = models.FloatField(default=0.0)
    analysis = models.TextField()

    def __str__(self):
        return f"{self.user.username} - {self.job_role} ({self.ats_score}%)"

class CommunityEvent(models.Model):
    event_name = models.CharField(max_length=255)
    description = models.TextField()
    banner = models.TextField()  # Store base64 image
    start_date = models.CharField(max_length=20)
    end_date = models.CharField(max_length=20)
    status = models.CharField(max_length=10, choices=[("active", "Active"), ("inactive", "Inactive")])

    def __str__(self):
        return self.event_name




# class MCQMockTest(models.Model):
#     mockid = models.AutoField(primary_key=True)
#     title = models.CharField(max_length=255)
#     user = models.ForeignKey(User, on_delete=models.CASCADE)
#     jdcontent = models.TextField()  # Extracted Job Description
#     mcqjson = models.JSONField()  # AI-Generated MCQs
#     mcqResp = models.TextField(blank=True)
#     improvements = models.TextField(blank=True)
#     result = models.TextField(blank=True)  # Auto-Generated Result
#     status = models.CharField(max_length=10, choices=[('new', 'New'), ('submitted', 'Submitted')], default='new')

#     def __str__(self):
#         return f"{self.title} - {self.user.username} ({self.status})"




class MCQMockTest(models.Model):
    mockid = models.AutoField(primary_key=True)
    title = models.CharField(max_length=255)
    user = models.ForeignKey(User, on_delete=models.CASCADE)
    jdcontent = models.TextField()  # Extracted Job Description
    mcqjson = models.JSONField()  # AI-Generated MCQs
    mcqResp = models.TextField(blank=True)
    improvements = models.TextField(blank=True)
    result = models.TextField(blank=True)  # Auto-Generated Result
    status = models.CharField(max_length=10, choices=[('new', 'New'), ('submitted', 'Submitted')], default='new')
    
    # ✅ Fix timestamp fields (Remove `default=None`)
    created_at = models.DateTimeField(auto_now_add=True)  # Stores creation time
    updated_at = models.DateTimeField(auto_now=True)  # Stores last modified time

    def __str__(self):
        return f"{self.title} - {self.user.username} ({self.status})"






class InterviewGen(models.Model):
    interviewid = models.AutoField(primary_key=True)
    title = models.CharField(max_length=255)
    user = models.ForeignKey(User, on_delete=models.CASCADE)
    jdcontent = models.TextField()  # Extracted Job Description
    questions = models.JSONField()  # AI-Generated Questions
    airesponse = models.TextField()  # Raw AI Response
    result = models.TextField(blank=True)  # Generated Result
    analysis = models.TextField(blank=True)  # Improvement Analysis
    status = models.CharField(max_length=10, choices=[('new', 'New'), ('submitted', 'Submitted')], default='new')

    def __str__(self):
        return f"{self.interviewid} {self.title} - {self.user.username} ({self.status})"






class InterviewResponse(models.Model):
    irid = models.AutoField(primary_key=True)
    
    interviewid = models.TextField()  
    username = models.TextField()  
    # username = models.ForeignKey(User, on_delete=models.CASCADE)
    classification = models.TextField()
    userresponse = models.TextField()
    extrainfo = models.TextField()

    def __str__(self):
        return f"{self.irid} - {self.username} {self.interviewid} {self.classification} {self.userresponse}"


class InterviewReport(models.Model):
    ireportid = models.AutoField(primary_key=True)
    
    interviewid = models.TextField()  
    user = models.ForeignKey(User, on_delete=models.CASCADE)
    reportcontent = models.TextField()

    def __str__(self):
        return f"{self.irid} - {self.user.username} {self.interviewid} {self.reportcontent}"








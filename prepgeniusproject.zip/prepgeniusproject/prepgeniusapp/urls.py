from django.urls import path
from . import views

urlpatterns = [
    path('', views.dashboard, name='dashboard'),

    path('userregister', views.user_register, name='user_register'),
    path('userlogin', views.user_login, name='user_login'),
    path('favcatselection', views.fav_cat_selection, name='fav_cat_selection'),
    path('uploadresume', views.upload_resume, name='upload_resume'),
    
    path('atsresultspage', views.ats_results_page, name='ats_results_page'),
    path('atsresult/<int:resume_id>/', views.ats_result_detail, name='ats_result_detail'),
    path('download/<int:resume_id>/<str:file_type>/', views.download_file, name='download_file'),

    path('userlogout', views.user_logout, name='user_logout'),
    path('aboutus/', views.about_us, name='about_us'),
    path("profile/", views.profile, name="profile"),



    path('mcqmocktestgenerator/', views.mcqmocktestgenerator, name='mcqmocktestgenerator'),
    path('mcqmocktestlist/', views.mcq_mock_test_list, name='mcq_mock_test_list'),
    path('mcqmocktestdetail/<int:mockid>/', views.mcq_mock_test_detail, name='mcq_mock_test_detail'),


    path('interviewgen/', views.interview_generator, name='interview_generator'),
    path('rxFrames/', views.rxFrames, name='rxFrames'),
    # path('rxAudio/', views.rxAudio, name='rxAudio'),
    path('rxAudio/', views.rx_audio, name='rx_audio'),
    path('nofacedetected/', views.nofacedetected, name='nofacedetected'),

    path('interviewlist/', views.interview_list, name='interview_list'),
    path('interviewdetail/<int:interviewid>/', views.interview_detail, name='interview_detail'),
    path('interviewresult/<int:interviewid>/', views.interview_result, name='interview_result'),
    path('interviewreport/<int:interviewid>/', views.interviewreport, name='interviewreport'),
    

    path('downloadreport/<int:interview_id>/', views.downloadreport, name='downloadreport'),

]

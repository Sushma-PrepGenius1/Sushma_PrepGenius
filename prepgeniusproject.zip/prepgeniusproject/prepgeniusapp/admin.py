from django.contrib import admin

from .models import FavCategory, ResumeDetails, CommunityEvent, MCQMockTest, InterviewGen, InterviewResponse, InterviewReport

# # Register your models here.

admin.site.register(FavCategory)
admin.site.register(ResumeDetails)
admin.site.register(CommunityEvent)
admin.site.register(MCQMockTest)
admin.site.register(InterviewGen)
admin.site.register(InterviewResponse)
admin.site.register(InterviewReport)
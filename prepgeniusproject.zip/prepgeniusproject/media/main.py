from moviepy import VideoFileClip
from pydub import AudioSegment
import os

def convertWebmToMp3(inputFile: str, outputMp3: str) -> None:
    """
    Converts a .webm video file to .mp4 and then extracts the audio as an .mp3 file.
    
    Args:
        inputFile (str): Path to the input .webm file.
        outputMp3 (str): Path to save the output .mp3 file.
    
    Returns:
        None
    """
    try:
        # Convert .webm to .mp4 using moviepy
        mp4File = os.path.splitext(inputFile)[0] + ".mp4"
        video = VideoFileClip(inputFile)
        video.write_videofile(mp4File, codec="libx264", audio_codec="aac")

        # Extract audio from .mp4 and save as .mp3
        audioFile = os.path.splitext(mp4File)[0] + ".wav"
        video.audio.write_audiofile(audioFile)

        # Convert WAV to MP3 using pydub
        audio = AudioSegment.from_file(audioFile, format="wav")
        audio.export(outputMp3, format="mp3")

        # Cleanup intermediate files
        os.remove(mp4File)
        os.remove(audioFile)

        print(f"Conversion successful! MP3 saved at: {outputMp3}")

    except Exception as e:
        print(f"Error: {e}")

# Example Usage
convertWebmToMp3("interview_.webm", "output.mp3")
